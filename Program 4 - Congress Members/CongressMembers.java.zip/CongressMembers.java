//CongressMembers.java
//Jason Yu
//1602944
//Programming Assignment 4: Sorting Approval Ratings
//The program takes the names and approval ratings of congressmen and sorts each person by order of first name and approval ratings.

public class CongressMembers {

	private String firstName;
	private String lastName;
	private double month1;
	private double month2;
	private double month3;
	private double month4;
	private double month5;

	public CongressMembers(String firstName, String lastName, double month1, double month2, double month3, double month4, double month5){
		this.firstName = firstName;
		this.lastName = lastName;
		this.month1 = month1;
		this.month2 = month2;
		this.month3 = month3;
		this.month4 = month4;
		this.month5 = month5;
	}

	public double getAverageRating(){
		double sum = month1 + month2 + month3 + month4 + month5;
		double avg = sum / 5;
		return avg;
	}

	public void setFirstName(String firstName){
		this.firstName = firstName;
	}
	
	public void setLastName(String lastName){
		this.lastName = lastName;
	}

	public void setMonth1(double month1){
		this.month1 = month1;
	}

	public void setMonth2(double month2){
		this.month2 = month2;
	}
	
	public void setMonth3(double month3){
		this.month3 = month3;
	}

	public void setMonth4(double month4){
		this.month4 = month4;
	}

	public void setMonth5(double month5){
		this.month5 = month5;
	}

	public String getFirstName(){
		return firstName;
	}

	public String getLastName(){
		return lastName;
	}

	public double getMonth1(){
		return month1;
	}

	public double getMonth2(){
		return month2;
	}

	public double getMonth3(){
		return month3;
	}

	public double getMonth4(){
		return month4;
	}

	public double getMonth5(){
		return month5;
	}


}
