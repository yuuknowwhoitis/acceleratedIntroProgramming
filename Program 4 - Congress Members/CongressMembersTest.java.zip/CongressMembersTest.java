//CongressMembersTest.java
//Jason Yu
//1602944
//Programming Assignment 4: Sorting Approval Ratings
//The program takes the names and approval ratings of congressmen and sorts each person by order of first name and approval ratings.

import java.util.*;
import java.io.*;

public class CongressMembersTest{
	
	public static void main(String[] args) throws FileNotFoundException{
		File file = new File("approval.txt");
		Scanner in = new Scanner(file);
		int counter = 0;

		CongressMembers[] members = new CongressMembers[53];
		for(int i = 0; i < members.length; i++){
			String firstName = in.next();
			String lastName = in.next();
			double month1 = in.nextDouble();
			double month2 = in.nextDouble();
			double month3 = in.nextDouble();
			double month4 = in.nextDouble();
			double month5 = in.nextDouble();
			members[i] = new CongressMembers(firstName, lastName, month1, month2, month3, month4, month5);
		}
		
		
		
		PrintStream outtt = new PrintStream(new File("output.txt"));
		outtt.println(53);
		outtt.println("Sorted by first name");
		members = sortByFirstName(members);
		for(int i = 0; i < members.length; i++){
			outtt.printf("%s %s %.2f %.2f %.2f %.2f %.2f\n", members[i].getFirstName(), members[i].getLastName(), members[i].getMonth1(), members[i].getMonth2(), members[i].getMonth3(), members[i].getMonth4(), members[i].getMonth5());
		}
		outtt.println();
		outtt.println();
		outtt.println("Sorted by approval rating");
		members = sortByFirstName(members);
		for(int i = 0; i < members.length; i++){
			outtt.printf("%s %s %.2f %.2f %.2f %.2f %.2f\n", members[i].getFirstName(), members[i].getLastName(), members[i].getMonth1(), members[i].getMonth2(), members[i].getMonth3(), members[i].getMonth4(), members[i].getMonth5());
		}


	}

	public static CongressMembers[] sortByFirstName(CongressMembers[] members){
		for(int i = 0; i < members.length - 1; i++){
			for(int j = 0; j < members.length - i - 1; j++){
				if(members[j].getFirstName().compareTo(members[j+1].getFirstName()) > 0){
					CongressMembers temp = members[j];
					members[j] = members[j + 1];
					members[j+1] = temp;
				}
			}
		}

		return members;
	}

	public static CongressMembers[] sortByApprovalRating(CongressMembers[] members){
		for(int i = 0; i < members.length - 1; i++){
			for(int j = 0; j < members.length - i - 1; j++){
				if(members[j].getAverageRating() > members[j+1].getAverageRating()){
					CongressMembers temp = members[j];
					members[j] = members[j+1];
					members[j+1] = temp;
				}
			}
		}
		return members;
	}

	




}